## git常用命令
@(git)[command]

-----
> https://git-scm.com/book/zh/v2
### 初次配置
一般在新的系统上，我们都需要先配置下自己的 Git 工作环境。配置工作只需一次，以后升级时还会沿用现在的配置。当然，如果需要，你随时可以用相同的命令修改已有的配置。
在 Windows 系统上，Git 会找寻用户主目录下的`.gitconfig` 文件。主目录即`$HOME` 变量指定的目录，一般都是 `C:\Documents and Settings\$USER`。
- 用户信息：
第一个要配置的是你个人的用户名称和电子邮件地址。这两条配置很重要，每次 Git 提交时都会引用这两条信息，说明是谁提交了更新，所以会随更新内容一起被永久纳入历史记录：
```
$ git config --global user.name "yourname"
$ git config --global user.email "email@example.com"
```
如果用了`--global`选项，那么更改的配置文件就是位于你用户主目录下的那个，以后你所有的项目都会默认使用这里配置的用户信息。如果要在某个特定的项目中使用其他名字或者电邮，只要去掉`--global`选项重新配置即可，新的设定保存在当前项目的`.git/config`文件里
```
$ cd gitlab-test/
$ cat .git/config
[core]
        repositoryformatversion = 0
        filemode = false
        bare = false
        logallrefupdates = true
        symlinks = false
        ignorecase = true
[remote "origin"]
        url = git@192.168.39.102:developers/gitlab-test.git
        fetch = +refs/heads/*:refs/remotes/origin/*
[branch "master"]
        remote = origin
        merge = refs/heads/master
[branch "develop"]
        remote = origin
        merge = refs/heads/develop
$ git config user.name "test"
$ git config user.email "test@test.com"
...
[user]
        name = test
        email = test@test.com
```
- 文本编辑器
Git 需要你输入一些额外消息的时候，会自动调用一个外部文本编辑器给你用。默认会使用操作系统指定的默认编辑器，一般可能会是`Vi`或者`Vim`。如果你有其他偏好，比如`Notepad`的话，可以重新设置：
`$ git config --global core.editor  "D:/'Program Files'/Notepad++/notepad++.exe"`
**注意**：`'Program Files'`因为中间有空格，所以必须使用单引号括起来。
- 删除配置
`$ git config --unset user.name`
- 查看配置
`$ git config <--global> --list`
### 获取帮助
想了解 Git 的各式工具该怎么用，可以阅读它们的使用帮助，方法有三：
```
$ git help <verb>
$ git <verb> --help
$ man git-<verb>
```
比如，要学习 config 命令可以怎么用，运行：
`$ git help config`
### 生成 SSH 公钥
大多数 Git 服务器都会选择使用 SSH 公钥来进行授权。系统中的每个用户都必须提供一个公钥用于授权，没有的话就要生成一个。生成公钥的过程在所有操作系统上都差不多。 首先先确认一下是否已经有一个公钥了。SSH 公钥默认储存在账户的主目录下的 ~/.ssh 目录。进去看看：
```
$ cd ~/.ssh/
$ ls
id_rsa  id_rsa.pub  known_hosts
```
`id_rsa.pub`文件是公钥，`id_rsa`文件是密钥。没有这些文件或者没有`.ssh`目录，可以用`ssh-keygen`来创建：
```
$ ssh-keygen -t rsa -C "your.email@example.com" <-b 4096>
Generating public/private rsa key pair.
Enter file in which to save the key (/Users/schacon/.ssh/id_rsa):
Enter passphrase (empty for no passphrase):
Enter same passphrase again:
Your identification has been saved in /Users/schacon/.ssh/id_rsa.
Your public key has been saved in /Users/schacon/.ssh/id_rsa.pub.
The key fingerprint is:
43:c5:5b:5f:b1:f1:50:43:ad:20:a6:92:6a:1f:9a:3a schacon@agadorlaptop.local
```
建议一直默认回车，不作信息更改。
### 获取仓库
有两种取得 Git 项目仓库的方法。 第一种是在现有项目或目录下导入所有文件到 Git 中； 第二种是从一个服务器克隆一个现有的 Git 仓库。
1. 在现有目录中初始化仓库
如果你打算使用 Git 来对现有的项目进行管理，你只需要进入该项目目录并输入：
`$ git init`
该命令将创建一个名为`.git`的子目录，这个子目录含有你初始化的 Git 仓库中所有的必须文件，这些文件是 Git 仓库的骨干。
如果你是在一个已经存在文件的文件夹（而不是空文件夹）中初始化 Git 仓库来进行版本控制的话，你应该开始跟踪这些文件并提交。 你可通过`git add`命令来实现对指定文件的跟踪，然后执行`git commit`提交。
```
$ git add .
$ git add LICENSE
$ git commit -m 'initial project version'
# 现在，你已经得到了一个实际维护（或者说是跟踪）着若干个文件的 Git 仓库。
```
2. 克隆现有的仓库
执行`git clone xxx`可以从Git服务器克隆仓库到本地：
`$ git clone git@192.168.39.102:developers/gitlab-test.git`
### git常用命令解读
#### 添加文件到版本库。
现在添加一个`README.md`到版本库中。
```
$ echo "# gitlab-test" >> README.md
$ git add README.md
```
命令`git add <filename>`将改动添加到暂存区。现在可以通过命令查看是否还有其他改动文件未提交：
```
$ git status
On branch master
Your branch is up to date with 'origin/master'.

Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

        modified:   README.md
```
查看哪些文件处于什么状态，可以用 `git status <-s|--short>` 命令。
接下来可以将改动提交到版本仓库，可以用`git commit `命令。
```
$ git commit -m "add read me content."
[master eb7738b] add read me content.
 1 file changed, 1 insertion(+)
```
继续修改`README.txt`，增加一行内容，然后通过`git status`查看文件状态。
```
$ echo "1111111111" >> README.md
$ git status
On branch master
Your branch is ahead of 'origin/master' by 1 commit.
  (use "git push" to publish your local commits)

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

        modified:   README.md

no changes added to commit (use "git add" and/or "git commit -a")
```
如果想查看`README.md`文件作了那些内容修改，可以通过命令`git diff <file>`查看。
```
$ git diff README.md
diff --git a/README.md b/README.md
index 7cbba67..fde4088 100644
--- a/README.md
+++ b/README.md
@@ -1 +1,2 @@
 # gitlab-test
+1111111
```
如上可以看到，带有`+`的一行，表示文件中新增了内容`1111111`，相对的，如果带有`-`，表示文件中删除了内容。
现在将修改提交到版本仓库。
```
$ git status
$ git add README.md
$ git commit -m "add content 1111111"
```
#### 查看历史记录
继续对`README.md`增加一行内容`2222222`，并提交：
```
$ echo "2222222" >> README.md
$ git add README.md
$ git commit -m "add content 2."
```
如果想查看提交的历史记录，可以通过命令`git log`。
```
$ git log
commit ee3c527dbb81adfdcd90f5a3638adfb7421d3bd6 (HEAD -> master)
Author: liuhao <767041809@qq.com>
Date:   Wed Jan 17 14:13:26 2018 +0800

    add content 2

commit fbcf972ad0bda7cd57bf81a81d52b9379140213c
Author: liuhao <767041809@qq.com>
Date:   Wed Jan 17 14:13:01 2018 +0800

    add content 1

commit eb7738bbbe1f82a916843c67b6ec22df52024659
Author: liuhao <767041809@qq.com>
Date:   Wed Jan 17 13:36:10 2018 +0800

    add read me content.

commit 769d8705ef51c067eff5edb4ae47214a518fa377 (origin/master, origin/develop, develop)
Author: liuhao <767041809@qq.com>
Date:   Wed Jan 17 10:54:45 2018 +0800

    initial commit.
```
`git log`命令显示从最近到最远的显示日志。可以通过参数配置让信息显示的更简洁，`git log --pretty=oneline`：
```
$ git log --pretty=oneline
ee3c527dbb81adfdcd90f5a3638adfb7421d3bd6 (HEAD -> master) add content 2
fbcf972ad0bda7cd57bf81a81d52b9379140213c add content 1
eb7738bbbe1f82a916843c67b6ec22df52024659 add read me content.
769d8705ef51c067eff5edb4ae47214a518fa377 (origin/master, origin/develop, develop) initial commit.
```
**说明：**git客户端自带的`gitk`可查看仓库的历史记录，并可以做可视化操作。执行命令`gitk`。
![gitk|center](./1516169637966.png)
#### 撤销修改
当对工作区的文件进行了修改操作，除了手动去撤销修改，还可以通过命令进行操作：
```
$ git checkout <file>
$ git checkout -- <file>
```
暂存区的文件撤销，需要将文件从暂存区回退到工作区，再执行`checkout`命令。
**注**：`checkout`除了撤销修改的功能，还可进行分支切换。`git checkout branch`。若分支名与文件名相同，此时撤销文件修改，则添加`--`即`git checkout -- <file>`。
#### 删除文件
对版本库的文件进行删除操作，本质上与添加修改等操作类型；可通过两种方式进行删除：
1. 直接在工作区进行删除
```
$ rm -rf <file>
$ git status
$ git add .
$ git commit -m "xxxx"
```
2. 执行`git rm <file>`
```
$ git rm <file>
$ git status
$ git commit -m "xxx"
```
`git rm`等价于`rm <file> git add <file>`。
删除的文件在`commit`之前同样可以通过`git checkout <file>`撤销删除。
#### 回退
回退主要涉及的命令是`git reset`。一般利用`git reset`可以达到两种回退操作。
1. 文件从暂存区回退到工作区。
`git reset HEAD <file>`：将指定文件从暂存区回退到工作区，也可使用`git reset <file>`。
`git reset HEAD`或者`git reset`：将暂存区所有文件回退到工作区。
2. 版本回退
`git reset HEAD^`：回退到上一个版本，一个`^`表示一个版本，以此类推，`^^`表示上上个版本。回退到多个版本，可使用`git reset HEAD~n`。
如果要回退到特定的一次提交，可使用命令`git reset commit-id`，commit-id可以通过`git reflog`查看。
```
$ git reflog
ee3c527 (HEAD -> master) HEAD@{0}: reset: moving to ee3c527
fbcf972 HEAD@{1}: reset: moving to HEAD^
ee3c527 (HEAD -> master) HEAD@{2}: reset: moving to HEAD
ee3c527 (HEAD -> master) HEAD@{3}: reset: moving to HEAD
ee3c527 (HEAD -> master) HEAD@{4}: reset: moving to HEAD^
67181d4 HEAD@{5}: reset: moving to HEAD
67181d4 HEAD@{6}: commit: test commit.
ee3c527 (HEAD -> master) HEAD@{7}: reset: moving to HEAD^
41ea6d0 HEAD@{8}: commit: test commit.
ee3c527 (HEAD -> master) HEAD@{9}: reset: moving to HEAD
ee3c527 (HEAD -> master) HEAD@{10}: commit: add content 2
```
输出的每一行左侧的七位十六进制的字符串即为`commit-id`。前面用`git log`一样可以查看commit-id，取前7位即可。
`git reset`常用的三个参数：`mixed`，`hard`，`soft`；默认参数为`mixed`。
使用`git reset -h | git reset --help`可查看`reset`的命令信息。
```
$ git reset -h
usage: git reset [--mixed | --soft | --hard | --merge | --keep] [-q] [<commit>]
   or: git reset [-q] [<tree-ish>] [--] <paths>...
   or: EXPERIMENTAL: git reset [-q] [--stdin [-z]] [<tree-ish>]
   or: git reset --patch [<tree-ish>] [--] [<paths>...]

    -q, --quiet           be quiet, only report errors
    --mixed               reset HEAD and index
    --soft                reset only HEAD
    --hard                reset HEAD, index and working tree
    --merge               reset HEAD, index and working tree
    --keep                reset HEAD but keep local changes
    --recurse-submodules[=<reset>]
                          control recursive updating of submodules
    -p, --patch           select hunks interactively
    -N, --intent-to-add   record only the fact that removed paths will be added later
    -z                    EXPERIMENTAL: paths are separated with NUL character
    --stdin               EXPERIMENTAL: read paths from <stdin>
```
- `soft`：`reset only HEAD`。`git reset --soft HEAD^`表示软回退到上一个版本。将版本库的HEAD重置到上一个提交，且将这次提交之后的所有变更移动到暂存区。可通过`git status`查看状态变更。
- `mixed`：`reset HEAD and index`。`git reset HEAD^`将HEAD重置到上次提交，而且会重置暂存区，将这次提交之后的所有变更都移动到为暂存阶段。
- `hard`：`reset HEAD, index and working tree`。`git reset --hard HEAD^`将HEAD重置到上次提交，重置暂存区，且工作区代码也会回退到上个版本。

注意**soft**参数与默认参数都不会修改工作区代码，只有**hard**参数才会修改工作区代码。
